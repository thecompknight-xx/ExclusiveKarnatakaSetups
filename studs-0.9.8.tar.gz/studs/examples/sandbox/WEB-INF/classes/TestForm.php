<?php
import('studs.action.ActionForm');
import('horizon.beanutils.ConvertUtils');

class TestForm extends ActionForm
{
	var $colors;

	function setColors($colors)
	{
		settype($colors, 'array');
		$this->colors = $colors;
	}

	function &getColors()
	{
		return $this->colors;
	}
}
?>
