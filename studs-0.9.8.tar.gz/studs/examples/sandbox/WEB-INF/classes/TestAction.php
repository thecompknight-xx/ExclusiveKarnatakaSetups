<?php
import('studs.action.Action');

class TestAction extends Action
{
	function &execute(&$mapping, &$form, &$request, &$response)
	{
		$request->setAttribute('favoriteColors', $form->getColors());
		return $mapping->findForward('testForm');	
	}
}
?>
