<?php
import('studs.util.LabelValueBean');

import('foo.bar.actions.mvc.SimpleFormController');
import('foo.bar.service.AdminService');
import('foo.bar.database.User');


/**
 * @package foo.bar.actions
 */
class AddUserController extends SimpleFormController
{

	function &prepareView(&$mapping, &$form, &$request, &$response) {

		$service = & new AdminService();

		$roles = $service->getRoles();


		$this->prepareOptions($request, $service, $form);
	}


	function doSubmitAction(&$form, &$request) {

		$service = & new AdminService();

		$role = $service->getRole($form->getRoleId());
		$user = & new User();

		$user->setFirstName($form->getFirstName());
		$user->setLastname($form->getLastname());
		$user->setLogonname($form->getLogonname());
		$user->setEmail($form->getEmail());
		$user->setEnabled(is_null($form->getEnabled()) ? 0 : 1);
		$user->setComment($form->getComment());
		$user->setPassword($form->getPassword());

		$user->setRole($role);


		$service->updateUser($user);
	}


	function prepareOptions(&$request, &$service, &$form)
	{
		$roles =& $service->getRoles();
		$rolesOptions = array();
		foreach ($roles as $role)
		{
			$roleOptions[] =& new LabelValueBean($role->getRolename(), $role->getId());
		}

		$form->setRoles($roleOptions);
	}

}
?>
