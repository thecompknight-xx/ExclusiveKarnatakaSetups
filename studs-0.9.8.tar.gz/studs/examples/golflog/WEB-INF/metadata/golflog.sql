CREATE DATABASE `golflog`;

USE `golflog`;

DROP TABLE IF EXISTS `courses`;
DROP TABLE IF EXISTS `players`;
DROP TABLE IF EXISTS `rounds`;

CREATE TABLE `courses` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `location` varchar(255) NOT NULL default '',
  `front_par` int(2) unsigned NOT NULL default '36',
  `back_par` int(2) unsigned NOT NULL default '36',
  `yardage` int(5) unsigned default '0',
  `rating` float unsigned default NULL,
  `slope` int(3) unsigned default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM COMMENT='The golf courses data.';

CREATE TABLE `players` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `last_name` varchar(50) NOT NULL default '',
  `first_name` varchar(50) NOT NULL default '',
  `handicap` smallint(3) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM COMMENT='The golf players data.';

CREATE TABLE `rounds` (
  `id` bigint(1) NOT NULL auto_increment,
  `score` smallint(6) NOT NULL default '0',
  `date` date default NULL,
  `player_id` bigint(20) NOT NULL default '0',
  `course_id` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM COMMENT='The golf rounds for each player.';
