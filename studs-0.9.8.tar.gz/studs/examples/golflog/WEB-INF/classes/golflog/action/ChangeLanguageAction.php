<?php
import('studs.action.Action');

class ChangeLanguageAction extends Action
{
	function &execute(&$mapping, &$form, &$request, &$response)
	{
		if ($form->getLocale() != "")
		{
			// FIXME: for some reason, I need to use the session in the page
			// in order for this to actually save to the session
			$this->setLocale($request, $form->getLocale());
		}

		return $mapping->findForward('home');
	}
}
?>
