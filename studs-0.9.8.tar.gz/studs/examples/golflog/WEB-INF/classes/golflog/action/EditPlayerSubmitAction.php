<?php
import('studs.action.Action');
import('studs.action.ActionMessage');
import('studs.action.ActionMessages');
import('golflog.service.GolfLogManager');

class EditPlayerSubmitAction extends Action
{
	function &execute(&$mapping, &$form, &$request, &$response)
	{
		// move on if form is cancelled or post data is stale
		if ($this->isCancelled($request) || !$this->isTokenValid($request, true))
		{
			return $mapping->findForward('next');
		}

		$manager =& new GolfLogManager($this->getDataSource($request));
		$player =& new Player(
			$form->getId(),
			$form->getFirstName(),
			$form->getLastName(),
			$form->getHandicap()
		);
		
		// TODO: catch any errors that occur here
		$manager->savePlayer($player);
		$manager->shutdown();

		// save lastEditId for guifications
		$session =& $request->getSession();
		$id = $player->getId();
		$session->setAttribute('lastEditId', $id);

		$messages =& new ActionMessages();
		$message =& new ActionMessage('message.edit.player.success');
		$messages->add(c('ActionMessages::GLOBAL_MESSAGE'), $message);
		$this->saveMessages($request, $messages, true);
		return $mapping->findForward('next');
	}
}
?>
