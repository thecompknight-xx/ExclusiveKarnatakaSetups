<?php
import('studs.action.Action');

import('golflog.service.GolfLogManager');

/**
 * @package golflog.action
 */
class EditPlayerAction extends Action
{
	function &execute(&$mapping, &$form, &$request, &$response)
	{
		if ($form->getId() != null)
		{
			$manager =& new GolfLogManager($this->getDataSource($request));
			$this->loadPlayer($request, $manager, $form);
			$manager->shutdown();
		}

		$request->setAttribute('context', ref('players'));
		$this->saveToken($request);
		return $mapping->findForward('editor');
	}

	function loadPlayer(&$request, &$manager, &$form)
	{
		$player =& $manager->getPlayer($form->getId());
		BeanUtils::copyProperties($form, $player);
	}
}
?>
