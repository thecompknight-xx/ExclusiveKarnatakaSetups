<?php
import('studs.action.Action');
import('studs.util.LabelValueBean');

import('golflog.service.GolfLogManager');

/**
 * @package golflog.action
 */
class EditRoundAction extends Action
{
	function &execute(&$mapping, &$form, &$request, &$response)
	{
		$manager =& new GolfLogManager($this->getDataSource($request));

		if ($form->getId() != null)
		{
			$this->loadRound($request, $manager, $form);
		}

		$this->prepareOptions($request, $manager, $form);
		$manager->shutdown();

		$request->setAttribute('context', ref('rounds'));
		$this->saveToken($request);
		return $mapping->findForward('editor');
	}

	function loadRound(&$request, &$manager, &$form)
	{
		$round =& $manager->getRound($form->getId());
		BeanUtils::copyProperties($form, $round);
	}

	function prepareOptions(&$request, &$manager, &$form)
	{
		$players =& $manager->getPlayers();
		$playerOptions = array();
		foreach ($players as $player)
		{
			$playerOptions[] =& new LabelValueBean($player->getNameLastFirst(), $player->getId());
		}

		$form->setPlayerOptions($playerOptions);

		$courses =& $manager->getCourses();
		$courseOptions = array();
		foreach ($courses as $course)
		{
			$courseOptions[] =& new LabelValueBean($course->getName(), $course->getId());
		}

		$form->setCourseOptions($courseOptions);
	}
}
?>
