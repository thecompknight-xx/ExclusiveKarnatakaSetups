<?php
import('studs.action.Action');

import('golflog.service.GolfLogManager');

/**
 * @package golflog.action
 */
class CourseListAction extends Action
{
	function &execute(&$mapping, &$form, &$request, &$response)
	{
		$manager =& new GolfLogManager($this->getDataSource($request));
		$courses =& $manager->getCourses();
		$manager->shutdown();

		$request->setAttribute('courses', $courses);
		$request->setAttribute('context', ref('courses'));
		return $mapping->findForward('list');
	}
}
?>
