<?php
import('studs.action.Action');

import('golflog.service.GolfLogManager');

/**
 * @package golflog.action
 */
class EditCourseAction extends Action
{
	function &execute(&$mapping, &$form, &$request, &$response)
	{
		if ($form->getId() != null)
		{
			$manager =& new GolfLogManager($this->getDataSource($request));
			$this->loadCourse($request, $manager, $form);
			$manager->shutdown();
		}

		$request->setAttribute('context', ref('courses'));
		$this->saveToken($request);
		return $mapping->findForward('editor');
	}

	function loadCourse(&$request, &$manager, &$form)
	{
		$course =& $manager->getCourse($form->getId());
		BeanUtils::copyProperties($form, $course);
	}
}
?>
