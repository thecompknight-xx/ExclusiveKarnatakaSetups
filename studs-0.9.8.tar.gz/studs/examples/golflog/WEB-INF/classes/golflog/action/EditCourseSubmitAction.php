<?php
import('studs.action.Action');
import('studs.action.ActionMessage');
import('studs.action.ActionMessages');
import('golflog.service.GolfLogManager');

class EditCourseSubmitAction extends Action
{
	function &execute(&$mapping, &$form, &$request, &$response)
	{
		// move on if form is cancelled or post data is stale
		if ($this->isCancelled($request) || !$this->isTokenValid($request, true))
		{
			return $mapping->findForward('next');
		}

		$manager =& new GolfLogManager($this->getDataSource($request));
		$course =& new Course(
			$form->getId(),
			$form->getName(),
			$form->getLocation(),
			$form->getFrontNinePar(),
			$form->getBackNinePar(),
			$form->getYardage(),
			$form->getRating(),
			$form->getSlope()
		);
		
		// TODO: catch any errors that occur here
		$manager->saveCourse($course);
		$manager->shutdown();

		// save lastEditId for guifications
		$session =& $request->getSession();
		$id = $course->getId();
		$session->setAttribute('lastEditId', $id);

		$messages =& new ActionMessages();
		$message =& new ActionMessage('message.edit.course.success');
		$messages->add(c('ActionMessages::GLOBAL_MESSAGE'), $message);
		$this->saveMessages($request, $messages, true);
		return $mapping->findForward('next');
	}
}
?>
