<?php
import('studs.action.Action');

import('golflog.service.GolfLogManager');

/**
 * @package golflog.action
 * @author Dan Allen
 */
class RoundListAction extends Action
{
	function &execute(&$mapping, &$form, &$request, &$response)
	{
		$manager =& new GolfLogManager($this->getDataSource($request));
		$rounds =& $manager->getRounds();
		$manager->shutdown();

		$request->setAttribute('rounds', $rounds);
		$request->setAttribute('context', ref('rounds'));
		return $mapping->findForward('list');
	}
}
?>
