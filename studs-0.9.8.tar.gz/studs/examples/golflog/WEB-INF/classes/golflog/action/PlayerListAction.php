<?php
import('studs.action.Action');

import('golflog.service.GolfLogManager');

/**
 * @package golflog.action
 * @author Dan Allen
 */
class PlayerListAction extends Action
{
	function &execute(&$mapping, &$form, &$request, &$response)
	{
		$manager =& new GolfLogManager($this->getDataSource($request));
		$courses =& $manager->getPlayers();
		$manager->shutdown();

		$request->setAttribute('players', $courses);
		$request->setAttribute('context', ref('players'));
		return $mapping->findForward('list');
	}
}
?>
