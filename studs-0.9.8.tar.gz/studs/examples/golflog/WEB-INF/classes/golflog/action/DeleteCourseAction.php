<?php
import('studs.action.Action');
import('studs.action.ActionMessage');
import('studs.action.ActionMessages');
import('golflog.service.GolfLogManager');

class DeleteCourseAction extends Action
{
	function &execute(&$mapping, &$form, &$request, &$response)
	{
		$manager =& new GolfLogManager($this->getDataSource($request));
		$id = $request->getParameter('id');
		// TODO: make sure id is valid or not null
		
		// TODO: catch any errors that occur here
		$manager->deleteCourse($id);
		$manager->shutdown();

		$messages =& new ActionMessages();
		$message =& new ActionMessage('message.delete.course.success');
		$messages->add(c('ActionMessages::GLOBAL_MESSAGE'), $message);
		$this->saveMessages($request, $messages, true);
		return $mapping->findForward('next');
	}
}
?>
