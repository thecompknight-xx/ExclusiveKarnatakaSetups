<?php
/**
 * @package golflog.model
 * @author Dan Allen
 */
class Player extends Object
{
	var $id = null;

	var $lastName;

	var $firstName;

	var $handicap;

	function Player($id = null, $firstName = '', $lastName = '', $handicap = 0)
	{
		$this->id = $id;
		$this->firstName = $firstName;
		$this->lastName = $lastName;
		$this->handicap = $handicap;
	}

	function getId()
	{
		return $this->id;
	}

	function getLastName()
	{
		return $this->lastName;
	}

	function getFirstName()
	{
		return $this->firstName;
	}

	function getHandicap()
	{
		return $this->handicap;
	}

	function getNameLastFirst()
	{
		return $this->lastName . ', ' . $this->firstName;
	}
}
?>
