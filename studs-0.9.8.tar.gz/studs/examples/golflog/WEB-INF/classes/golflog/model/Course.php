<?php
/**
 * @package golflog.model
 * @author Dan Allen
 */
class Course extends Object
{
	var $id = null;

	var $name;

	var $location;

	var $backNinePar;

	var $frontNinePar;

	var $yardage;

	var $rating;

	var $slope;

	function Course($id = null, $name = '', $location = null, $frontNinePar = 36, $backNinePar = 36, $yardage = null, $rating = null, $slope = null)
	{
		$this->id = $id;
		$this->name = $name;
		$this->location = $location;
		$this->backNinePar = $backNinePar;
		$this->frontNinePar = $frontNinePar;
		$this->yardage = $yardage;
		$this->rating = $rating;
		$this->slope = $slope;
	}

	function getId()
	{
		return $this->id;
	}

	function setId($id)
	{
		$this->id = $id;
	}

	function getName()
	{
		return $this->name;
	}

	function getLocation()
	{
		return $this->location;
	}

	function getTotalPar()
	{
		return $this->backNinePar + $this->frontNinePar;
	}

	function getBackNinePar()
	{
		return $this->backNinePar;
	}

	function getFrontNinePar()
	{
		return $this->frontNinePar;
	}

	function getYardage()
	{
		return $this->yardage;
	}

	function getRating()
	{
		return $this->rating;
	}

	function getSlope()
	{
		return $this->slope;
	}

	function getSlopeRating()
	{
		if (is_null($this->rating) && is_null($this->slope))
		{
			return null;
		}

		return $this->rating . '/' . $this->slope;
	}
}
?>
