<?php
/**
 * @package golflog.model
 * @author Dan Allen
 */
class Round extends Object
{
	var $id = null;

	var $score = 0;

	var $date = null;

	var $player = null;

	var $playerId = null;

	var $course = null;

	var $courseId = null;

	function Round($id = null, $score = 0, $date = null, $player = null, $course = null)
	{
		$this->id = $id;
		$this->score = $score;
		$this->date = $date;

		if (!is_null($player))
		{
			if (is_a($player, 'Player'))
			{
				$this->player =& $player;
			}
			else
			{
				$this->playerId = $player;
			}
		}

		if (!is_null($course))
		{
			if (is_a($course, 'Course'))
			{
				$this->course =& $course;
			}
			else
			{
				$this->courseId = $course;
			}
		}
	}

	function getId()
	{
		return $this->id;
	}

	function getScore()
	{
		return $this->score;
	}

	function getDate()
	{
		return $this->date;
	}

	function getPlayer()
	{
		return $this->player;
	}

	function getPlayerId()
	{
		return is_null($this->player) ? $this->playerId : $this->player->getId();
	}

	function getCourse()
	{
		return $this->course;
	}

	function getCourseId()
	{
		return is_null($this->course) ? $this->courseId : $this->course->getId();
	}
}
?>
