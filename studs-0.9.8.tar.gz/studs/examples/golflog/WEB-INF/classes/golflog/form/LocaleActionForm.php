<?php
import('studs.action.ActionForm');
import('studs.action.ActionMessage');
import('studs.action.ActionMessages');
import('studs.action.ActionMessages');

class LocaleActionForm extends ActionForm
{
	var $locale;

	function setLocale($locale)
	{
		$this->locale = $locale;
	}

	function getLocale()
	{
		return $this->locale;
	}

	/**
	 * Set the locale to the initial statae
	 */
	function reset(&$mapping, &$request) {
		$this->locale = RequestUtils::getUserLocale($request);
	}
}
?>
