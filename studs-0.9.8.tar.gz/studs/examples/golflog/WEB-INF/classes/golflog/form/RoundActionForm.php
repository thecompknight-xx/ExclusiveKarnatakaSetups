<?php
import('studs.action.ActionForm');
import('studs.action.ActionMessage');
import('studs.action.ActionMessages');

class RoundActionForm extends ActionForm
{
	var $id;

	var $date;

	var $score;

	var $playerId;

	var $courseId;

	var $playerOptions = array();

	var $courseOptions = array();

	function setId($id)
	{
		$this->id = $id;
	}

	function setDate($date)
	{
		$this->date = $date;
	}

	function setScore($score)
	{
		$this->score = $score;
	}

	function setPlayerId($playerId)
	{
		$this->playerId = $playerId;
	}

	function setCourseId($courseId)
	{
		$this->courseId = $courseId;
	}

	function setPlayerOptions($options)
	{
		$this->playerOptions = $options;
	}

	function setCourseOptions($options)
	{
		$this->courseOptions = $options;
	}

	function getId()
	{
		return $this->id;
	}

	function getDate()
	{
		return $this->date;
	}

	function getScore()
	{
		return $this->score;
	}

	function getPlayerId()
	{
		return $this->playerId;
	}

	function getCourseId()
	{
		return $this->courseId;
	}

	function getPlayerOptions()
	{
		return $this->playerOptions;
	}

	function getCourseOptions()
	{
		return $this->courseOptions;
	}

	function validate(&$mapping, &$request)
	{
		$errors =& new ActionMessages();

		// FIXME: this doesn't really validate a date
 		if (!preg_match('/^[0-9]{4}-[0-2][0-9]-[0-3][0-9]$/', $this->getDate()))
		{
			$errors->add(c('ActionMessages::GLOBAL_MESSAGE'), new ActionMessage('errors.valid_date', 'Date'));
		}
 
		if (!is_numeric($this->getScore()) || $this->getScore() <= 0)
		{
			$errors->add(c('ActionMessages::GLOBAL_MESSAGE'), new ActionMessage('errors.positive_numeric', 'Score'));
		}
 
		return $errors;
	}
}
?>
