<?php
import('studs.action.ActionForm');
import('studs.action.ActionMessage');
import('studs.action.ActionMessages');

class CourseActionForm extends ActionForm
{
	var $id;

	var $name;	

	var $location;

	var $frontNinePar;

	var $backNinePar;

	var $yardage;

	var $slope;

	var $rating;

	function setId($id)
	{
		$this->id = $id;
	}

	function setName($name)
	{
		$this->name = $name;
	}

	function getId()
	{
		return $this->id;
	}

	function getName()
	{
		return $this->name;
	}

	function setLocation($location)
	{
		$this->location = $location;
	}

	function getLocation()
	{
		return $this->location;
	}

	function setFrontNinePar($par)
	{
		$this->frontNinePar = $par;
	}

	function getFrontNinePar()
	{
		return $this->frontNinePar;
	}

	function setBackNinePar($par)
	{
		$this->backNinePar = $par;
	}

	function getBackNinePar()
	{
		return $this->backNinePar;
	}

	function setYardage($yardage)
	{
		$this->yardage = $yardage;
	}

	function getYardage()
	{
		return $this->yardage;
	}

	function setSlope($slope)
	{
		$this->slope = $slope;
	}

	function getSlope()
	{
		return $this->slope;
	}

	function setRating($rating)
	{
		$this->rating = $rating;
	}

	function getRating()
	{
		return $this->rating;
	}

	// TODO: make sure location is in the form <city, STATE>
	function validate(&$mapping, &$request)
	{
		$errors =& new ActionMessages();
 
		$this->setName(strip_tags($this->getName()));
		$this->setLocation(strip_tags($this->getLocation()));

		if (strlen($this->getName()) == 0)
		{
			$errors->add(c('ActionMessages::GLOBAL_MESSAGE'), new ActionMessage('errors.required', 'Course Name'));
		}
 
		if (strlen($this->getLocation()) == 0)
		{
			$errors->add(c('ActionMessages::GLOBAL_MESSAGE'), new ActionMessage('errors.required', 'Location'));
		}

		if (!is_numeric($this->getFrontNinePar()) || $this->getFrontNinePar() <= 0)
		{
			$errors->add(c('ActionMessages::GLOBAL_MESSAGE'), new ActionMessage('errors.positive_numeric', 'Front Nine'));
		}

		if (!is_numeric($this->getBackNinePar()) || $this->getBackNinePar() <= 0)
		{
			$errors->add(c('ActionMessages::GLOBAL_MESSAGE'), new ActionMessage('errors.positive_numeric', 'Back Nine'));
		}

		if (!is_numeric($this->getSlope()))
		{
			$errors->add(c('ActionMessages::GLOBAL_MESSAGE'), new ActionMessage('errors.numeric', 'Slope'));
		}

		if (!is_numeric($this->getRating()))
		{
			$errors->add(c('ActionMessages::GLOBAL_MESSAGE'), new ActionMessage('errors.numeric', 'Rating'));
		}
		
		if (!is_numeric($this->getYardage()))
		{
			$errors->add(c('ActionMessages::GLOBAL_MESSAGE'), new ActionMessage('errors.numeric', 'Yardage'));
		}
 
		return $errors;
	}

	/**
	 * Setup default values for the form
	 */
	function reset(&$mapping, &$request)
	{
		$this->frontNinePar = 36;
		$this->backNinePar = 36;
	}
}
?>
