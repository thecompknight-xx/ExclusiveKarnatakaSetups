<?php
import('studs.action.ActionForm');
import('studs.action.ActionMessage');
import('studs.action.ActionMessages');

class PlayerActionForm extends ActionForm
{
	var $id;

	var $lastName;

	var $firstName;

	var $handicap;

	function setId($id)
	{
		$this->id = $id;
	}

	function setLastName($lastName)
	{
		$this->lastName = $lastName;
	}

	function setFirstName($firstName)
	{
		$this->firstName = $firstName;
	}

	function setHandicap($handicap)
	{
		$this->handicap = $handicap;
	}

	function getId()
	{
		return $this->id;
	}

	function getLastName()
	{
		return $this->lastName;
	}

	function getFirstName()
	{
		return $this->firstName;
	}

	function getHandicap()
	{
		return $this->handicap;
	}

	function validate(&$mapping, &$request)
	{
		$errors =& new ActionMessages();
 
		$this->setFirstName(strip_tags($this->getFirstName()));
		$this->setLastName(strip_tags($this->getLastName()));

		if (strlen($this->getFirstName()) == 0)
		{
			$errors->add(c('ActionMessages::GLOBAL_MESSAGE'), new ActionMessage('errors.required', 'First Name'));
		}
 
		if (strlen($this->getLastName()) == 0)
		{
			$errors->add(c('ActionMessages::GLOBAL_MESSAGE'), new ActionMessage('errors.required', 'Last Name'));
		}

		if (!is_numeric($this->getHandicap()))
		{
			$errors->add(c('ActionMessages::GLOBAL_MESSAGE'), new ActionMessage('errors.numeric', 'Handicap'));
		}
 
		return $errors;
	}
}
?>
