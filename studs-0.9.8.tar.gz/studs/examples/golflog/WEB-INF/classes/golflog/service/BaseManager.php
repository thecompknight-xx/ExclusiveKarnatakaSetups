<?php
/**
 * @package golflog.service
 */
class BaseManager extends Object
{
	var $ds = null;

	function BaseManager(&$dataSource)
	{
		$this->ds =& $dataSource;
	}
}
?>
