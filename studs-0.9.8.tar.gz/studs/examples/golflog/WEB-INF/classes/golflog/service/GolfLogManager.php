<?php
import('golflog.service.BaseManager');
import('golflog.model.Course');
import('golflog.model.Player');
import('golflog.model.Round');

/**
 * @package golflog.service
 * @author Dan Allen
 *
 * TODO: consolidate the logic here
 */
class GolfLogManager extends BaseManager
{
	function &getRounds()
	{
		$rounds = array();
		$conn =& $this->ds->getConnection();
		$stmt =& $conn->prepareStatement('
			SELECT
				*, r.id round_id
			FROM
				rounds r, players p, courses c
			WHERE
				r.player_id = p.id AND r.course_id = c.id
		');
		$rs =& $stmt->executeQuery();
		if (!is_null($rs))
		{
			while ($rs->next())
			{
				$player =& new Player(
					$rs->getInt('player_id'),
					$rs->getString('first_name'),
					$rs->getString('last_name'),
					$rs->getInt('handicap')
				);

				$course =& new Course(
					$rs->getInt('course_id'),
					$rs->getString('name'),
					$rs->getString('location'),
					$rs->getInt('front_par'),
					$rs->getInt('back_par'),
					$rs->getInt('yardage'),
					$rs->getFloat('rating'),
					$rs->getInt('slope')
				);

				$rounds[] =& new Round(
					$rs->getInt('round_id'),
					$rs->getInt('score'),
					$rs->getString('date'), // TODO: make this a Date
					$player,
					$course
				);
			}

			$rs->close();
		}

		return $rounds;
	}

	function &getRound($id)
	{
		$round = null;
		$conn =& $this->ds->getConnection();
		$stmt =& $conn->prepareStatement('SELECT * FROM rounds WHERE id = ?');
		$stmt->setInt(1, $id);
		$rs =& $stmt->executeQuery();
		if (!is_null($rs))
		{
			if ($rs->next())
			{
				$round =& new Round(
					$rs->getInt('id'),
					$rs->getString('score'),
					$rs->getString('date'),
					$rs->getInt('player_id'),
					$rs->getInt('course_id')
				);
			}

			$rs->close();
		}

		return $round;
	}

	function &getPlayers()
	{
		$players = array();
		$conn =& $this->ds->getConnection();
		$stmt =& $conn->prepareStatement('SELECT * FROM players');
		$rs =& $stmt->executeQuery();
		if (!is_null($rs))
		{
			while ($rs->next())
			{
				$players[] =& new Player(
					$rs->getInt('id'),
					$rs->getString('first_name'),
					$rs->getString('last_name'),
					$rs->getInt('handicap')
				);
			}

			$rs->close();
		}

		return $players;
	}

	function &getPlayer($id)
	{
		$player = null;
		$conn =& $this->ds->getConnection();
		$stmt =& $conn->prepareStatement('SELECT * FROM players WHERE id = ?');
		$stmt->setInt(1, $id);
		$rs =& $stmt->executeQuery();
		if (!is_null($rs))
		{
			if ($rs->next())
			{
				$player =& new Player(
					$rs->getInt('id'),
					$rs->getString('first_name'),
					$rs->getString('last_name'),
					$rs->getInt('handicap')
				);
			}

			$rs->close();
		}

		return $player;
	}

	function &getCourses()
	{
		$courses = array();
		$conn =& $this->ds->getConnection();
		$stmt =& $conn->prepareStatement('SELECT * FROM courses');
		$rs =& $stmt->executeQuery();
		if (!is_null($rs))
		{
			while ($rs->next())
			{
				$courses[] =& new Course(
					$rs->getInt('id'),
					$rs->getString('name'),
					$rs->getString('location'),
					$rs->getInt('front_par'),
					$rs->getInt('back_par'),
					$rs->getInt('yardage'),
					$rs->getFloat('rating'),
					$rs->getInt('slope')
				);
			}

			$rs->close();
		}


		return $courses;
	}

	function &getCourse($id)
	{
		$course = null;
		$conn =& $this->ds->getConnection();
		$stmt =& $conn->prepareStatement('SELECT * FROM courses WHERE id = ?');
		$stmt->setInt(1, $id);
		$rs =& $stmt->executeQuery();
		if (!is_null($rs))
		{
			if ($rs->next())
			{
				$course =& new Course(
					$rs->getInt('id'),
					$rs->getString('name'),
					$rs->getString('location'),
					$rs->getInt('front_par'),
					$rs->getInt('back_par'),
					$rs->getInt('yardage'),
					$rs->getFloat('rating'),
					$rs->getInt('slope')
				);
			}

			$rs->close();
		}

		return $course;
	}

	/**
	 * @return void
	 */
	function saveRound(&$round)
	{
		if (!is_empty($round->getId()))
		{
			$sql = 'UPDATE rounds SET score = ?, date = ?, player_id = ?, course_id = ? WHERE id = ?';
		}
		else
		{
			$sql = 'INSERT INTO rounds VALUES (NULL, ?, ?, ?, ?)';
		}

		$conn =& $this->ds->getConnection();
		$stmt =& $conn->prepareStatement($sql);
		$row = 1;
		$stmt->setString($row++, $round->getScore());
		$stmt->setString($row++, $round->getDate());
		$stmt->setInt($row++, $round->getPlayerId());
		$stmt->setInt($row++, $round->getCourseId());
		if (!is_empty($round->getId()))
		{
			$stmt->setInt($row++, $round->getId());
		}

		$stmt->executeUpdate();
		if (is_empty($round->getId()))
		{
			$rs =& $stmt->getResultSet();
			// protected level access!
			$round->id = $rs->getUpdateID();
		}
	}

	function deleteRound($id)
	{
		$conn =& $this->ds->getConnection();
		$stmt =& $conn->prepareStatement('DELETE FROM rounds WHERE id = ?');
		$stmt->setInt(1, $id);
		$stmt->executeUpdate();
	}

	/**
	 * @return void
	 */
	function saveCourse(&$course)
	{
		if (!is_empty($course->getId()))
		{
			$sql = 'UPDATE courses SET name = ?, location = ?, front_par = ?, back_par = ?, yardage = ?, rating = ?, slope = ? WHERE id = ?';
		}
		else
		{
			$sql = 'INSERT INTO courses VALUES (NULL, ?, ?, ?, ?, ?, ?, ?)';
		}

		$conn =& $this->ds->getConnection();
		$stmt =& $conn->prepareStatement($sql);
		$row = 1;
		$stmt->setString($row++, $course->getName());
		$stmt->setString($row++, $course->getLocation());
		$stmt->setInt($row++, $course->getFrontNinePar());
		$stmt->setInt($row++, $course->getBackNinePar());
		$stmt->setInt($row++, $course->getYardage());
		$stmt->setFloat($row++, $course->getRating());
		$stmt->setFloat($row++, $course->getSlope());
		if (!is_empty($course->getId()))
		{
			$stmt->setInt($row++, $course->getId());
		}

		$stmt->executeUpdate();
		if (is_empty($course->getId()))
		{
			$rs =& $stmt->getResultSet();
			// protected level access!
			$course->id = $rs->getUpdateID();
		}
	}

	function deleteCourse($id)
	{
		$conn =& $this->ds->getConnection();
		$stmt =& $conn->prepareStatement('DELETE FROM rounds WHERE course_id = ?');
		$stmt->setInt(1, $id);
		$stmt->executeUpdate();

		$stmt =& $conn->prepareStatement('DELETE FROM courses WHERE id = ?');
		$stmt->setInt(1, $id);
		$stmt->executeUpdate();
	}

	function savePlayer(&$player)
	{
		if (!is_empty($player->getId()))
		{
			$sql = 'UPDATE players SET last_name = ?, first_name = ?, handicap = ? WHERE id = ?';
		}
		else
		{
			$sql = 'INSERT INTO players VALUES (NULL, ?, ?, ?)';
		}

		$conn =& $this->ds->getConnection();
		$stmt =& $conn->prepareStatement($sql);
		$row = 1;
		$stmt->setString($row++, $player->getLastName());
		$stmt->setString($row++, $player->getFirstName());
		$stmt->setInt($row++, $player->getHandicap());
		if (!is_empty($player->getId()))
		{
			$stmt->setInt($row++, $player->getId());
		}

		$stmt->executeUpdate();
		if (is_empty($player->getId()))
		{
			$rs =& $stmt->getResultSet();
			// protected level access!
			$player->id = $rs->getUpdateID();
		}
	}

	function deletePlayer($id)
	{
		$conn =& $this->ds->getConnection();
		$stmt =& $conn->prepareStatement('DELETE FROM rounds WHERE player_id = ?');
		$stmt->setInt(1, $id);
		$stmt->executeUpdate();

		$stmt =& $conn->prepareStatement('DELETE FROM players WHERE id = ?');
		$stmt->setInt(1, $id);
		$stmt->executeUpdate();
	}

	/**
	 * Close open connection.
	 */
	function shutdown()
	{
		$conn =& $this->ds->getConnection();
		$conn->close();
	}
}
?>
