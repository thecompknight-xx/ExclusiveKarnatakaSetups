/**
 * Created by Nick Chapman (http://chapnickman.com/)
 * Information: http://chapnickman.com/2005/03/08/yellow-fade-technique/
 * License: Attribution-ShareAlike 2.0 (http://creativecommons.org/licenses/by-sa/2.0/)
 * Version 1.0-emergis
 * Modifications By: Dan Allen (dan.allen@emergis.com)
 */

Fader._prefix = "tada-";

Fader._instances = new Array();

Fader._updateColor = function (elementNode, color)
{
	elementNode.style.backgroundColor = color;
}

Fader._progressFade = function(instance)
{
	if (instance.percent < 100)
	{
		instance.percent += instance.increase;

		instance.callback.call(this, instance.elementNode, Fader._getColor(instance.start, instance.end, instance.percent));

		setTimeout("Fader._progressFade(Fader._instances[" + instance.index + "])", instance.speed);
	}
	else
	{
		instance.percent = 0;
	}
}

// Code from codingforums.com
// -- http://www.codingforums.com/archive/index.php/t-4656

Fader._getColor = function (start, end, percent)
{
	var r1 = Fader._hex2dec(start.slice(0,2));
	var g1 = Fader._hex2dec(start.slice(2,4));
	var b1 = Fader._hex2dec(start.slice(4,6));

	var r2 = Fader._hex2dec(end.slice(0,2));
	var g2 = Fader._hex2dec(end.slice(2,4));
	var b2 = Fader._hex2dec(end.slice(4,6));

	var pc = percent / 100;

	r = Math.floor(r1 + (pc * (r2-r1)) + .5);
	g = Math.floor(g1 + (pc * (g2-g1)) + .5);
	b = Math.floor(b1 + (pc * (b2-b1)) + .5);

	return("#" + Fader.dec2hex(r) + Fader.dec2hex(g) + Fader.dec2hex(b));
}

Fader._hexDigit = new Array("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F");

Fader.dec2hex = function (dec)
{
	return(Fader._hexDigit[dec>>4] + Fader._hexDigit[dec&15]);
}

Fader._hex2dec = function (hex)
{
	return(parseInt(hex,16))
}

Fader._rgb2hex = function(str)
{
	var result;
	var rgb = str.match(/rgb\s*\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)/);
	if (rgb) {
		var r = parseInt(rgb[1]);
		var g = parseInt(rgb[2]);
		var b = parseInt(rgb[3]);
		r = r.toString(16); if (r.length == 1) r = '0' + r;
		g = g.toString(16); if (g.length == 1) g = '0' + g;
		b = b.toString(16); if (b.length == 1) b = '0' + b;
		result = r + g + b;
	}
	// handle case in which we were passed a hex with a "#"
	else if (str.indexOf("#") == 0) {
		result = str.substr(1);
	}
	// handle case in which we were passed a hex without a "#"
	else {
		result = str;
	}

	return result;
}

Fader._getComputedBackgroundColor = function(obj)
{
	var color;
	if (window.getComputedStyle) {
		color = window.getComputedStyle(obj, null).getPropertyValue("background-color");
	}
	else if (obj.currentStyle) {
		color = obj.currentStyle.backgroundColor;
	}
	
	// NOTE: default to white if no color specified
	if (color == "" || color == "transparent") {
		color = "rgb(255, 255, 255)";
	}

	return Fader._rgb2hex(color);
}


/**
 * TODO: this code could be cleaned up so that the calls to _getComputedBackgroundColor
 * don't happen unless start/end are not provided
 */
function Fader(elementNode, callback, start, end, speed, increase)
{
	this.percent = 0;
	this.callback = null;
	this.end = Fader._getComputedBackgroundColor(elementNode);
	elementNode.className += " tada";
	this.start = Fader._getComputedBackgroundColor(elementNode);
	this.speed = 50;
	this.elementNode = elementNode;
	this.increase = 2;
	
	if (start) {
		if (start.charAt(0) == "#")
			this.start = start.substring(1, start.length);
		else
			this.start = start;
	}

	if (end) {
		if (end.charAt(0) == "#")
			this.end = end.substring(1, end.length);
		else
			this.end = end;
	}

	this.callback = callback;

	if (speed != null)
		this.speed = speed;

	if (increase != null)
		this.increase = increase;
	
	this.index = Fader._instances.length;
	
	Fader._instances[this.index] = this;
}

Fader.prototype.fade = function()
{
	Fader._progressFade(this);
}

/**
 * Kick off the fader, running through the document ids searching
 * for prefixes the signify a fade event.
 */
function yft_init()
{
	var cnt = 0;
	var item;
	var faders = [];
	while ((elementNode = document.getElementById(Fader._prefix + cnt)))
	{
		faders[cnt] = new Fader(elementNode, Fader._updateColor);	
		faders[cnt].fade();
		cnt++;
	}
}
