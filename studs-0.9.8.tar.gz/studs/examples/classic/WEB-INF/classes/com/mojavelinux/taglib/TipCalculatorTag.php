<?php
import('phase.tagext.TagSupport');
import('phase.support.ELEvaluator');

class TipCalculatorTag extends TagSupport
{
	var $total;

	var $billExpression;

	var $tipExpression;

	var $bill;

	var $tip;

	var $var;

	var $scope;

	function TipCalculatorTag()
	{
		$this->init();
	}

	function setBill($bill)
	{
		$this->billExpression = $bill;
	}

	function setTip($tip)
	{
		$this->tipExpression = $tip;
	}

	function setVar($var)
	{
		$this->var = $var;
	}

	function setScope($scope)
	{
		$this->scope = $scope;
	}

	function init()
	{
		$this->scope = 'page';

		$this->var = null;

		$this->bill = 0;

		$this->total = 0;

		$this->tip = 15;
	}

	function doStartTag()
	{
		$this->evaluateExpressions();

		$this->total = doubleval($this->bill + round($this->bill * $this->tip)/100);
		if (is_null($this->var))
		{
			echo $this->total;
		}
		else
		{
			$this->pageContext->setAttribute($this->var, $this->total, $this->scope);
		}
	}

	function evaluateExpressions()
	{
		if (!is_null($this->billExpression))
		{
			$this->bill = ELEvaluator::evaluate('bill', $this->billExpression, 'double', $this->pageContext);
		}

		if (!is_null($this->tipExpression))
		{
			$this->tip = ELEvaluator::evaluate('bill', $this->tipExpression, 'double', $this->pageContext);
		}
	}

	function release()
	{
		parent::release();
		$this->init();
	}
}
?>
