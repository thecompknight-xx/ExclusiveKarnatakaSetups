<?php
import('stratus.servlets.HttpServlet');

class HelloWorld extends HttpServlet
{
	function printHeader(&$response)
	{
		$response->setContentType('text/html');
		echo '<html><body><title>Invoker Servlet Example</title><h1>Invoker Servlet Example</h1>';
	}

	function printFooter(&$request, &$response)
	{
		echo '<hr />';
		echo '<div style="font-size: small;">&laquo; <a href="' . $request->getContextPath() . '/">back</a></div>';
		echo '</body></html>';
	}

	function doGet(&$request, &$response)
	{
		$this->printHeader($response);

		echo '<form method="post">';
		echo '<label for="name">What is your name?</label> <input type="text" name="name" id="name" />';
		echo '<input type="submit" value="Submit" />';
		echo '</form>';
		echo '<p><small>(That was a GET operation)</small></p>';
		$this->printFooter($request, $response);
	}

	function doPost(&$request, &$response)
	{
		$this->printHeader($response);

		echo '<h3>Hello ' . $request->getParameter('name') . '!</h3>';
		echo '<p>If you would like to try again, <a href="">click here</a>.</p>';
		echo '<p><small>(That was a POST operation)</small></p>';
		$this->printFooter($request, $response);
	}
}
?>
