Installing the Examples
=======================

 In order to run the examples, certain directories have to be copied from the
 main studs source tree (meaning these examples are not independent as
 structured in the CVS tree).
 
 In the following instructions, the root of the studs tree will be referenced
 as $STUDS_CVS and the example application directory will be shown as $EXAMPLE.

 1. Copy the following files:

 $STUDS_CVS/conf/index.php -> $EXAMPLE/
 $STUDS_CVS/conf/.htaccess -> $EXAMPLE/

 2. Copy (recursively) the following directories (or use a symlink):

 $STUDS_CVS/src -> $EXAMPLE/WEB-INF/lib
 $STUDS_CVS/conf/tld -> $EXAMPLE/WEB-INF/tld

 3. Make the work directory and set it to be read/write by the web server

 mkdir $EXAMPLE/WEB-INF/work
 chmod 777 $EXAMPLE/WEB-INF/work

 4. Fire up the browser and hit the index.php file under $EXAMPLE to begin!

 The quickest way to accomplish this is to decend into the WEB-INF/classes directory
 of one of the examples and executing:

 ant prepare
