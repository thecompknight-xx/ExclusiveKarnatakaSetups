#!/usr/bin/php
<?php
error_reporting(E_ALL);
ini_set('include_path', implode(':', array('.', '../src', '../tests')));
require_once 'horizon/init.php';

import('horizon.util.unittest.runner.TextRunner');
TextRunner::main($_SERVER['argv']);
?>
