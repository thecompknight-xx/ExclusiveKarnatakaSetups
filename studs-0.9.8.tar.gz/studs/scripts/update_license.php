<?php
/**
 * This script takes a glob of files and updates the license to the license
 * file in PHP scripts using the text included in the constant LICENSE_TEXT
 * (should we use the LICENSE file?).
 */

def('LICENSE_TEXT', <<<LICENSE
/* \$Id: update_license.php 340 2006-05-09 04:48:03Z mojavelinux $
 *
 * Copyright 2003-2005 Dan Allen, Mojavelinux.com (dan.allen@mojavelinux.com)
 *
 * This project was originally created by Dan Allen, but you are permitted to
 * use it, modify it and/or contribute to it.  It has been largely inspired by
 * a handful of other open source projects and public specifications, most
 * notably Apache's Jakarta Project and Sun Microsystem's J2EE SDK.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
LICENSE
);

foreach ($argv as $index => $arg)
{
	$filename = basename($arg);
	// skip if first argument or not a class file (doesn't begin with uppercase)
	if ($index == 0 || strtoupper($filename{0}) != $filename{0}) continue;

	$ret = update_license($arg);
}

function update_license($filepath)
{
	$contents = get_source($filepath);
	// @todo someway here to determine if we just want to skip it all together

	// license already exists, overwrite it
	if (preg_match(';^<\?php\n/\*.*?\n.*?\n \*/;s', $contents, $matches))
	{
		$contents = '<?php' . "\n" . LICENSE_TEXT . substr($contents, strlen($matches[0]));
	}
	// no license exists, insert one
	else
	{
		$contents = '<?php' . "\n" . LICENSE_TEXT . "\n\n" . substr($contents, 6);
	}

	write_source($filepath, $contents);
	return true;
}

function get_source($filepath)
{
	return file_get_contents($filepath);
}

function write_source($filepath, $source)
{
	$fp = fopen($filepath, 'w');
	fwrite($fp, $source);
	fclose($fp);
}
?>
