#!/usr/bin/perl

# See below for require modules

# Steps for release:
# 1. check in all files
# 2. update Changelog and RELEASE-NOTES.txt
# 3. update the project.release.version in build.properties
# 4. run `ant package' (also in examples)
# 5. use notes section from RELEASE-NOTES.txt to make Notes file (in release)
# 6. copy changelog for current release to Chanages (in release)
# 7. tag CVS tree
# 8. run sf-release.sh
# 9. publish to website and update website info
# 10. publish with antmeat

# TODO: use the root ANNOUNCEMENTS for the notes in build

use lib '/home/dallen/lib/perl';
use Net::Sourceforge;

my $release_version;

open (BUILD_PROPERTIES, '../build.properties');

while ($line = <BUILD_PROPERTIES>) {
	if ($line =~ /^project.release.version=(.*)/) {
		$release_version = $1;
		break;
	}
}

close(BUILD_PROPERTIES);

die('Release version could not be determined') unless $release_version;

my $sf_user = 'mojavelinux';
my $release_dir = '../releases/' . $release_version;
my $group_id = 76836;
my $type_id = 3002;
my $packages = {
	studs 	=> 77627,
	basic	=> 77681,
	classic	=> 125169,
	golflog => 149353,
};

# FIXME: make a better way for these switches
my $doStuds = 1;
my $doBasic = 1;
my $doClassic = 1;
my $doGolflog = 1;

chdir $release_dir;

# = Studs (full source)
if ($doStuds) {

	my $main_release = Net::Sourceforge->new(
		module			=> 'studs',
	    sf_user         => $sf_user,
	    sf_package_id   => $packages->{studs},
	    sf_group_id     => $group_id,
		sf_type_id		=> $type_id,
	);
	
	$main_release->readin_password();
	
	$main_release->ftp_upload();
	sleep 5;
	$main_release->sf_release();

}

# = Studs Starter Application
if ($doBasic) {

	my $basic_release = Net::Sourceforge->new(
		module			=> 'studs-basic',
		changes_file    => 'SeeChanges',
		notes_file      => 'SeeNotes',
	    sf_user         => $sf_user,
	    sf_package_id   => $packages->{basic},
	    sf_group_id     => $group_id,
	    sf_type_id		=> $type_id,
	);
	
	$basic_release->readin_password();
	
	$basic_release->ftp_upload();
	sleep 5;
	$basic_release->sf_release();

}

# = Stratus Servlet Examples
if ($doClassic) {

	my $stratus_release = Net::Sourceforge->new(
		module			=> 'stratus-classic',
		changes_file    => 'SeeChanges',
		notes_file      => 'SeeNotes',
	    sf_user         => $sf_user,
	    sf_package_id   => $packages->{classic},
	    sf_group_id     => $group_id,
		sf_type_id		=> $type_id,
	);
	
	$stratus_release->readin_password();
	
	$stratus_release->ftp_upload();
	sleep 5;
	$stratus_release->sf_release();

}

# = Golflog Demo Application
if ($doGolflog) {

	my $main_release = Net::Sourceforge->new(
		module			=> 'golflog',
		changes_file    => 'SeeChanges',
		notes_file      => 'SeeNotes',
	    sf_user         => $sf_user,
	    sf_package_id   => $packages->{golflog},
	    sf_group_id     => $group_id,
		sf_type_id		=> $type_id,
	);
	
	$main_release->readin_password();
	
	$main_release->ftp_upload();
	sleep 5;
	$main_release->sf_release();

}

print "release complete!\n";
exit 0;

# required modules:
#   Net::SourceForge
#   TermReadKey
#   IO::Socket::SSL
#   Net::SSLeay
# 	WWW::Mechanize
