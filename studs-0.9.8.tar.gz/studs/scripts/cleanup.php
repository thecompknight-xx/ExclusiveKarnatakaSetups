<?php
unlink('/tmp/php-servlet.log');
?>
