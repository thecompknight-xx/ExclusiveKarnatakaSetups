#!/bin/sh

find $1 -name '*.php' -exec php -l {} \;
