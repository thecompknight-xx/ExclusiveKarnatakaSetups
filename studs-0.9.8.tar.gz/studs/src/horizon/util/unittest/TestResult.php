<?php
/* $Id: TestResult.php 306 2005-07-21 04:14:42Z mojavelinux $
 *
 * Copyright 2003-2005 Dan Allen, Mojavelinux.com (dan.allen@mojavelinux.com)
 *
 * This project was originally created by Dan Allen, but you are permitted to
 * use it, modify it and/or contribute to it.  It has been largely inspired by
 * a handful of other open source projects and public specifications, most
 * notably Apache's Jakarta Project and Sun Microsystem's J2EE SDK.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import('horizon.util.unittest.TestFailure');

/**
 * <p>Special thanks goes to Kent Beck and Erich Gamma for writing JUnit,
 * the inspiration behind this unit test implementation.</p>
 */
class TestResult extends Object
{
	var $failures = array();

	var $errors = array();

	function addFailure(&$test, &$e)
	{
		$this->failures[] =& new TestFailure($test, $e);
	}

	function addError(&$test, &$e)
	{
		$this->errors[] =& new TestFailure($test, $e);
	}

	function getErrorCount()
	{
		return count($this->errors);
	}

	function getFailureCount()
	{
		return count($this->failures);
	}

	// NOTE: do not want a reference here
	function getFailures()
	{
		return $this->failures;
	}

	function getErrors()
	{
		return $this->errors;
	}

	function run(&$test)
	{
		// try {
		$test->runBare();	
		// } catch (AssertionFailedException $e) {
		if ($e = catch_exception('AssertionFailedException'))
		{
			$this->addFailure($test, $e);
		}
		else if ($e = catch_exception())
		{
			$this->addError($test, $e);
		}
		// }
	}

	/**
	 * Returns whether the entire test was successful or not.
	 *
	 * @return boolean
	 */
	function wasSuccessful()
	{
		return (!$this->getFailureCount() && !$this->getErrorCount());
	}
}
?>
