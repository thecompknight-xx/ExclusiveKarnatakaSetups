<?php
ini_set('include_path', '../src:../examples/sandbox/WEB-INF/classes');
include 'horizon/init.php';
import('horizon.io.StringReader');
import('horizon.text.Scanner');
//$scanner =& new Scanner(new StringReader('${\'n\"o}end\'}after'));
//$scanner =& new Scanner(new StringReader('"we should find no \"s in here"'));
//while ($scanner->hasMoreInput())
//{
//	echo $scanner->nextChar();
//}
//$scanner->nextChar();
//$start = $scanner->mark();
//$stop = $scanner->skipUntil('"', true);
//echo $scanner->getChars($start, $stop);
$scanner =& new Scanner(new StringReader('\'big\"dan\'+'));
$quote = $scanner->nextChar();
echo $scanner->skipUntil($quote, true, array('\''));
echo $scanner->nextChar();
//echo $scanner->parseToken(false);
?>
