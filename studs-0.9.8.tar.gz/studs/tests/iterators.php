<?php
ini_set('include_path', '.:../src');
include 'horizon/init.php';
import('horizon.collections.iterators.ListIterator');
import('horizon.util.StopWatch');

//$w =& new StopWatch();
$array = range(1, 10000);
for ($it =& new ListIterator($array); $it->hasNext();)
{
	echo $it->next() . "\n";
}
/*
echo $w->read(true) . "\n";
$len = count($array);
for ($i = 0; $i < $len; $i++)
{
	$array[$i];
}
echo $w->read(true) . "\n";
*/
?>
