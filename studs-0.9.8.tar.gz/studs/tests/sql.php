<?php
ini_set('include_path', '../src:../examples/sandbox/WEB-INF/classes');
include_once 'horizon/init.php';
import('horizon.sql.DriverManager');
import('horizon.collections.IteratorUtils');

Clazz::forName('horizon.sql.drivers.MySQLDriver');
$url = 'mysql://localhost:3306/cpknatives?user=jwhite&password=white';
$conn =& DriverManager::getConnection($url);
/*
$stmt =& $conn->createStatement();
echo $stmt->executeUpdate('update user set username = \'daniel.allen\' where username = \'dan.allen\'');
*/
$stmt =& $conn->prepareStatement('select * from news where newsId = ?');
$stmt->setInt(1, 1);
$stmt->setInt(1, 2);
$result =& $stmt->executeQuery();
$result->next();
echo $result->getString('title');

$result->close();
$conn->close();
if ($e = catch_exception())
{
	$e->printStackTrace();
}
?>
