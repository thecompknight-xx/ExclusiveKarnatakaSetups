<?php
import('horizon.io.File');
import('horizon.util.unittest.TestCase');

class FileTest extends TestCase
{
	function testMkdirs()
	{
		$path = '/tmp/filetest-' . mt_rand() . '/blank';
		$dir = new File($path);
		$dir->mkdirs();
		Assert::assertTrue(file_exists($path), 'The directory tree was not created.');
		// cleanup
		$dir->delete();
		$parent =& $dir->getParentFile();
		$parent->delete();
	}
}
?>
