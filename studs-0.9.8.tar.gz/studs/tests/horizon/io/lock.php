<?php
ini_set('include_path', '../../../src');
ini_set('allow_call_time_pass_reference', 'On');
include_once 'horizon/init.php';
import('horizon.io.FileWriter');
$writer =& new FileWriter(ref('test.txt'));
$lock =& $writer->lock();
echo 'Lock obtained in ' . __FILE__ . "\n";
$writer->write('This is new content from lock.php');
sleep(10);
$lock->release();
$writer->close();
?>
