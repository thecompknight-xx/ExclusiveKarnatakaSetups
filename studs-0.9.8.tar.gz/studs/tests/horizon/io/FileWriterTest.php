<?php
import('horizon.io.File');
import('horizon.io.FileWriter');
import('horizon.util.unittest.TestCase');

class FileWriterTest extends TestCase
{
	function testTruncate()
	{
		$file =& new File(dirname(__FILE__) . '/filewritertest_0.txt');
		// first put in some test data
		$writer =& new FileWriter($file);
		$writer->write('sample data');
		$writer->close();

		// open for writing in append note, then truncate
		$writer =& new FileWriter($file, true);
		$writer->truncate();
		$writer->close();

		$len = $file->length();

		$file->delete();

		Assert::assertTrue($len == 0, 'The file should have been truncated to 0 length.');
	}
}
?>
