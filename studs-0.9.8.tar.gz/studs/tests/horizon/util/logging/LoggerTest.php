<?php
import('horizon.util.unittest.TestCase');
import('horizon.util.logging.Logger');

// override default location for logging configuration
def('LogManager::CONFIG', dirname(__FILE__) . '/logging.properties');

class LoggerTest extends TestCase
{
	var $logFile;

	var $log;

	function setup()
	{
		$this->logFile = dirname(__FILE__) . '/test.log';
		@unlink($this->logFile);
		$this->log =& Logger::getLogger($this->getClassName());

		// fix to local log file
		$appenders = $this->log->appenders;
		$appenders[0]->setFile($this->logFile);
	}

	function testDebug()
	{
		$this->log->debug('Test debug log');
		$result =& new File($this->logFile);
		$this->assertTrue($result->exists(), 'Log file was not created');
	}
}
?>
