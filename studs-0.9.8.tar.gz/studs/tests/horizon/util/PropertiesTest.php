<?php
import('horizon.util.unittest.TestCase');
import('horizon.util.Properties');
import('horizon.util.PlaceholderAwareProperties');
import('horizon.io.FileReader');

class PropertiesTest extends TestCase
{
	function testLoad()
	{
		$properties =& new Properties();
		$properties->load(new FileReader(ref(dirname(__FILE__) . '/sample.properties')));	
		$this->assertEquals('two', $properties->getProperty('one'));
		$this->assertEquals("This is an intro paragraph that is multiple lines.", $properties->getProperty('intro'));
		$this->assertEquals('localhost', $properties->getProperty('db.host'));
	}

	function testResolvePlaceholders()
	{
		$properties =& new PlaceholderAwareProperties();
		$properties->put('url.base', '/app');
		$properties->put('url.images', '${url.base}/images');
		$properties->resolvePlaceholders();
		$this->assertEquals('/app/images', $properties->getProperty('url.images'));		
	}
}
?>
