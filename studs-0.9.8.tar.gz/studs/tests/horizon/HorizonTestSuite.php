<?php
import('horizon.util.unittest.TestSuite');
import('horizon.util.unittest.TestResult');

class HorizonTestSuite extends TestSuite
{
	/**
	 * Create the test suite instance, adding the various tests to
	 * be run, then return the suite.
	 *
	 * @static
	 */
	function &suite()
	{
		$suite =& new TestSuite();
		$suite->addTestSuite(Clazz::forName('horizon.lang.ObjectTest'));
		$suite->addTestSuite(Clazz::forName('horizon.lang.ClazzTest'));

		$suite->addTestSuite(Clazz::forName('horizon.io.FileTest'));
		$suite->addTestSuite(Clazz::forName('horizon.io.FileWriterTest'));

		$suite->addTestSuite(Clazz::forName('horizon.util.PropertiesTest'));
		$suite->addTestSuite(Clazz::forName('horizon.beanutils.BeanUtilsTest'));
		$suite->addTestSuite(Clazz::forName('horizon.beanutils.PropertyUtilsTest'));
		$suite->addTestSuite(Clazz::forName('horizon.beanutils.ConvertUtilsTest'));

		$suite->addTestSuite(Clazz::forName('horizon.util.logging.LoggerTest'));
		return $suite;
	}
}
?>
