<?php
import('horizon.util.StopWatch');
import('horizon.util.unittest.TestCase');

class ClazzTest extends TestCase
{
	function testIsAssignableFrom()
	{
		$clazz =& Clazz::forName('horizon.lang.IllegalArgumentException', false);
		$this->assertTrue($clazz->isAssignableFrom('RootException'), 'Invalid class hierarchy evaluation');
	}

	function testGetQualifiedClass()
	{
		$shortClassName = 'TestCase';
		$fullClassName = Clazz::getQualifiedName($shortClassName);
		$this->assertEquals('horizon.util.unittest.TestCase', $fullClassName, 'Fully qualified class invalid!');

		$shortClassName = 'HorizonTestSuite';
		$fullClassName = Clazz::getQualifiedName($shortClassName);
		$this->assertEquals('horizon.HorizonTestSuite', $fullClassName, 'Fully qualified class invalid!');
	}
}
?>
