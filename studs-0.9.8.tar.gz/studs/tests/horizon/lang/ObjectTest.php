<?php
import('horizon.util.StopWatch');
import('horizon.util.unittest.TestCase');

class ObjectTest extends TestCase
{
	function testInstanceOfClass()
	{
		$str =& new String('my string');
		Assert::assertTrue($str->instanceOfClass('String'), 'Object is an instance of String');	
		Assert::assertTrue(is_a($str, 'String'), 'Object is an instance of String');
	}

	function testWriteObject()
	{
		$example =& new TestCase('example');
		$serializedFile = dirname(__FILE__) . '/test.ser';
		@unlink($serializedFile);
		$writer = new FileWriter($serializedFile);	
		$example->writeObject($writer);
		$output = file_get_contents($serializedFile);
		$this->assertTrue(preg_match(':require_once \'[^\']*/TestCase\.php\';:', $output), 'Imports are missing'); 
		$this->assertTrue(preg_match(':return unserialize\(:', $output), 'Serialization data is missing');
	}

	/**
	 * Profile the Object::instanceOfClass() method
	 *
	function testInstanceOfTime()
	{
		$str =& new String('my string');

		$repeats = 100000;
		echo 'Object::instanceOfClass() vs is_a() speed comparison, Iterations: ' . $repeats . "\n";
		$timer =& new StopWatch();

		for ($i = 0; $i < $repeats; $i++)
		{
			$str->instanceOfClass('String');
		}

		echo 'Object::instanceOfClass: ' . $timer->read(true) . "\n";

		for ($i = 0; $i < $repeats; $i++)
		{
			is_a($str, 'String');
		}

		echo 'is_a: ' . $timer->read(true) . "\n";
	}
	*/
}
?>
