<?php
// a sample data object
class SamplePersonBean extends Object
{
	var $name;

	var $age;

	var $friends;

	function SamplePersonBean($name = null)
	{
		$this->name = $name;
		$this->friends = array();
	}

	function getName()
	{
		return $this->name;
	}

	function setName($name)
	{
		$this->name = $name;
	}

	function getAge()
	{
		return $this->age;
	}

	function setAge($age)
	{
		$this->age = $age;
	}

	function addFriend(&$person)
	{
		$this->friends[] =& $person;
	}

	function setFriends(&$friends)
	{
		$this->friends =& $friends;
	}

	function &getBestFriend()
	{
		if (count($this->friends) > 0)
		{
			return $this->friends[0]; 
		}

		return null;
	}

	function getFriends()
	{
		return $this->friends;
	}
}
