<?php
import('horizon.util.unittest.TestCase');
import('horizon.beanutils.PropertyUtils');
import('horizon.beanutils.SamplePersonBean');

class PropertyUtilsTest extends TestCase
{
	var $jack;

	function setUp()
	{
		$this->jack =& new SamplePersonBean('Jack');	

		$jill =& new SamplePersonBean('Jill');
		$mary =& new SamplePersonBean('Mary');
		$this->jack->addFriend($jill);
		$this->jack->addFriend($mary);
	}

	/**
	 * Test a simple property set.
	 */
	function testSetSimpleProperty()
	{
		PropertyUtils::setSimpleProperty($this->jack, 'name', ref('John'));
		$this->assertEquals('John', $this->jack->getName());
	}

	/**
	 * Test a simple property get.
	 */
	function testGetSimpleProperty()
	{
		$result = PropertyUtils::getSimpleProperty($this->jack, 'name');
		$this->assertEquals('Jack', $result);
	}

	/**
	 * Test a random property get, possibly nested.
	 */
	function testGetProperty()
	{
		$result = PropertyUtils::getProperty($this->jack, 'bestFriend.name');
		$this->assertEquals('Jill', $result);
	}

	/**
	 * Test a nested/indexed property get.
	 */
	function testGetNestedProperty()
	{
		$result = PropertyUtils::getNestedProperty($this->jack, 'friends[1].name');
		$this->assertEquals('Mary', $result);
	}

	/**
	 * Test an indexed property.
	 */
	function testGetIndexedProperty()
	{
		$result =& PropertyUtils::getNestedProperty($this->jack, 'friends[1]');
		$this->assertEquals('Mary', $result->getName());
	}
}
?>
