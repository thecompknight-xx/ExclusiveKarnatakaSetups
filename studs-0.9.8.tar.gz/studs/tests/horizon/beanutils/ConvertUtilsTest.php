<?php
import('horizon.util.unittest.TestCase');
import('horizon.beanutils.ConvertUtils');

class ConvertUtilsTest extends TestCase
{
	function testConvertBoolean()
	{
		$value = 'true';
		$this->assertTrue(ConvertUtils::convert($value, 'boolean'), 'String "true" should result in true value');

		$value = '1';
		$this->assertTrue(ConvertUtils::convert($value, 'boolean'), 'String "1" should result in true value');

		$value = null;
		$this->assertFalse(ConvertUtils::convert($value, 'boolean'), 'null should result in false value');

		$value = 'false';
		$this->assertFalse(ConvertUtils::convert($value, 'boolean'), 'String "false" should result in false value');

		$value = '0';
		$this->assertFalse(ConvertUtils::convert($value, 'boolean'), 'String "0" should result in false value');
	}
}
?>
