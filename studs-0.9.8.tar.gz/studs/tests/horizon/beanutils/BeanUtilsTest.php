<?php
import('horizon.util.unittest.TestCase');
import('horizon.beanutils.BeanUtils');
import('horizon.beanutils.SamplePersonBean');

class BeanUtilsTest extends TestCase
{
	var $jack;
	
	function setUp()
	{
		$this->jack =& new SamplePersonBean('Jack');	
		$this->jack->setAge(25);

		$jill =& new SamplePersonBean('Jill');
		$mary =& new SamplePersonBean('Mary');
		$this->jack->addFriend($jill);
		$this->jack->addFriend($mary);
	}

	/**
	 * Test a set property in a nested context.
	 */
	function testNestedSetProperty()
	{
		BeanUtils::setProperty($this->jack, 'friends[1].name', ref('Sarah'));
		$this->assertEquals('Sarah', $this->jack->friends[1]->getName());
	}

	function testCloneBean()
	{
		$result =& BeanUtils::cloneBean($this->jack);
		$this->assertNotNull($this->jack);
		$this->assertEquals($this->jack->getName(), $result->getName());
		$this->assertEquals(count($this->jack->getFriends()), count($result->getFriends()));
	}

	function testCopyProperties()
	{
		$jack2 =& new SamplePersonBean();
		BeanUtils::copyProperties($jack2, $this->jack);
		$this->assertEquals(25, $jack2->getAge());
		$this->assertEquals(2, count($jack2->getFriends()));
	}
}
?>
