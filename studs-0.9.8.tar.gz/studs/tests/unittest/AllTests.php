<?php
import('horizon.util.unittest.TestSuite');
import('horizon.util.unittest.TestResult');

class AllTests extends TestSuite
{
	/**
	 * Create the test suite instance, adding the various tests to
	 * be run, then return the suite.
	 *
	 * @static
	 */
	function &suite()
	{
		$suite =& new TestSuite();
		$suite->addTestSuite(Clazz::forName('unittest.MathTest'));
		$suite->addTestSuite(Clazz::forName('unittest.CalcTest'));
		return $suite;
	}
}
?>
