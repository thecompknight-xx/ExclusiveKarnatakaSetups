<?php
import('horizon.util.unittest.TestCase');

Class MathTest extends TestCase
{
	var $value1;
	var $value2;

	function setUp()
	{
    	$this->value1 = 2.0;
		$this->value2 = 3.0;
	}

	function testAddPass()
	{
		echo "running CalcTest::testAddPass()\n";
		$result = $this->value1 + $this->value2;
		$this->assertEquals($result, 5.0);
	}

	function testAddFail()
	{
		echo "running CalcTest::testAddFail()\n";
		$result = $this->value1 + $this->value2;
		$this->assertEquals($result, 4.0);
	}

	function testSubtract()
	{
		echo "running CalcTest::testSubtract()\n";
		$result = $this->value2 - $this->value1;
		$this->assertEquals($result, 1.0);
	}
}
?>
