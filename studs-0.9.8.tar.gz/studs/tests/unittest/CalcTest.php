<?php
import('horizon.util.unittest.TestCase');

class CalcTest extends TestCase
{
	var $value1 = 2.0;
	var $value2 = 3.0;

	function testMultiply()
	{
		echo "running CalcTest::testMultiply()\n";
		$result = $this->value1 * $this->value2;
		$this->assertEquals($result, 6.0);
	}
}
?>
