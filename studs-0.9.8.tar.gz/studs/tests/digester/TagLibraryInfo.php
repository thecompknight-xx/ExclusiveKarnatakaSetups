<?php
/**
 * A tag library, which includes an array of tags that match the jsp page.
 */
class TagLibraryInfo
{
	var $tags = array();

	var $prefix;

	var $version;

	var $uri;

	function addTag(&$tag)
	{
		$this->tags[] =& $tag;
	}

	function &getTags()
	{
		return $this->tags;
	}

	/**
	 * Find a tag in this library by name.
	 *
	 * @param string $name The name of the the tag
	 * @return TagInfo The tag corresponding to the name, or null if not found
	 */
	function &getTag($name)
	{
		for ($i = 0; $i < count($this->tags); $i++)
		{
			if ($this->tags[$i]->getName() == $name)
			{
				return $this->tags[$i];
			}
		}

		return null;
	}

	function setPrefix($prefix)
	{
		$this->prefix = $prefix;
	}

	function getPrefix()
	{
		return $this->prefix;
	}

	function setVersion($version)
	{
		$this->version = $version;
	}

	function getVersion()
	{
		return $version;
	}

	function setUri($uri)
	{
		$this->uri = $uri;
	}

	function getUri()
	{
		return $this->uri;
	}
}
?>
