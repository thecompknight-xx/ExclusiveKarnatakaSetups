<?php
/* $Id: StudentsDigester.php 223 2005-06-23 23:11:06Z mojavelinux $
 *
 * Copyright 2003-2005 Dan Allen, Mojavelinux.com (dan.allen@mojavelinux.com)
 *
 * This project was originally created by Dan Allen, but you are permitted to
 * use it, modify it and/or contribute to it.  It has been largely inspired by
 * a handful of other open source projects and public specifications, most
 * notably Apache's Jakarta Project and Sun Microsystem's J2EE SDK.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

include 'setupenv.php';

import('horizon.io.FileReader');
import('horizon.xml.digester.Digester');

class StudentsDigester
{
    var $students;

    function StudentsDigester()
	{
        $this->students = array();
    }

    function digest()
	{
        //try {
            $digester =& new Digester();
            //Push the current object onto the stack
            $digester->push($this);

            //Creates a new instance of the Student class
            $digester->addObjectCreate('students/student', 'horizon.xml.digester.tests.Student');

            //Uses setName method of the Student instance
            //Uses tag name as the property name
            $digester->addBeanPropertySetter('students/student/name');

            //Uses setCourse method of the Student instance
            //Explicitly specify property name as 'course'
            $digester->addBeanPropertySetter('students/student/course', 'course');

            //Move to next student
            $digester->addSetNext('students/student', 'addStudent', 'horizon.xml.digester.tests.Student');

            $ds =& $digester->parse(new FileReader($tmp = 'students.xml'));

        //} catch (RootException $ex) {
		if ($ex = catch_exception())
		{
            $ex->printStackTrace();
			return;
        }

        //Print the contents of the Vector
        print("The students array contains:\n");
		foreach ($ds->students as $student)
		{
			print("\t" . $student->toString() . "\n");
		}
    }

    function addStudent($student)
	{
        // add a new Student instance to the Vector
        $this->students[] =& $student;
    }
}

$studentsDigester =& new StudentsDigester();
$studentsDigester->digest();
?>
