<?php
/* $Id: TldDigester.php 223 2005-06-23 23:11:06Z mojavelinux $
 *
 * Copyright 2003-2005 Dan Allen, Mojavelinux.com (dan.allen@mojavelinux.com)
 *
 * This project was originally created by Dan Allen, but you are permitted to
 * use it, modify it and/or contribute to it.  It has been largely inspired by
 * a handful of other open source projects and public specifications, most
 * notably Apache's Jakarta Project and Sun Microsystem's J2EE SDK.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

include 'setupenv.php';

import('horizon.io.FileReader');
import('horizon.xml.digester.Digester');

class TldDigester
{
    var $taglibs;

    function TldDigester()
	{
        $this->taglibs = array();
    }

    function digest()
	{
        //try {
            $digester =& new Digester();

            $digester->addObjectCreate('taglib', 'horizon.xml.digester.tests.TagLibraryInfo');

            $digester->addBeanPropertySetter('taglib/tlib-version', 'version');

            $digester->addBeanPropertySetter('taglib/short-name', 'prefix');

            $digester->addBeanPropertySetter('taglib/uri');

            $digester->addObjectCreate('taglib/tag', 'horizon.xml.digester.tests.TagInfo');

            $digester->addBeanPropertySetter('taglib/tag/name');

            $digester->addBeanPropertySetter('taglib/tag/tag-class', 'tagClass');

            $digester->addSetNext('taglib/tag', 'addTag', 'horizon.xml.digester.tests.TagInfo');

            $ds =& $digester->parse(new FileReader($tmp = 'c.tld'));

        //} catch (RootException $ex) {
		if ($ex = catch_exception())
		{
            $ex->printStackTrace();
			return;
        }

        //Print the contents of the Vector
        print("The taglibs array contains:\n");
		print_r($ds);
    }
}

$tldDigester =& new TldDigester();
$tldDigester->digest();
?>
