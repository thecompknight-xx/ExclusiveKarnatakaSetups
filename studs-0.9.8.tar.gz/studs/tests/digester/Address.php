<?php
/* $Id: Address.php 188 2005-04-07 04:52:31Z mojavelinux $
 *
 * Copyright 2003-2005 Dan Allen, Mojavelinux.com (dan.allen@mojavelinux.com)
 *
 * This project was originally created by Dan Allen, but you are permitted to
 * use it, modify it and/or contribute to it.  It has been largely inspired by
 * a handful of other open source projects and public specifications, most
 * notably Apache's Jakarta Project and Sun Microsystem's J2EE SDK.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



/**
* Bean for Digester testing.
*/
class Address {

	function Address($street="Main Street", $city="Mossman", 
							$state="Down Under", $zipCode="MyZip") {
		$this->setStreet($street);		// String
		$this->setCity($city);			// String
		$this->setState($state);			// String
		$this->setZipCode($zipCode);	// String
	}

	var $city = NULL; // private String

	function getCity() {
		return $this->city; // String
	}

	function setCity($city) {
		$this->city = $city; // String
	}


	var $state = NULL; // private String

	function getState() {
		return $this->state; // String
	}

	function setState($state) {
		$this->state = $state; // String
	}


	var $street = NULL; // private String

	function getStreet() {
		return $this->street; // String
	}

	function setStreet($street) {
		$this->street = $street; // String
	}


	var $type = NULL; // private String

	function getType() {
		return $this->type; // String
	}

	function setType($type) {
		$this->type = $type; // String
	}


	var $zipCode = NULL; // private String

	function getZipCode() {
		return $this->zipCode; // String
	}

	function setZipCode($zipCode) {
		$this->zipCode = $zipCode; // String
	}


	function setEmployee(&$employee) {
		$employee->addAddress($this);	// Employee
	}


	function toString() {
		$sb = "Address[";
		$sb = "street=";
		$sb = $this->street;
		$sb = ", city=";
		$sb = $this->city;
		$sb = ", state=";
		$sb = $this->state;
		$sb = ", zipCode=";
		$sb = $this->zipCode;
		$sb = "]";
		return $sb;
    }


	/* JCW
	* Add a new custom configuration property.
	*
	* @param name String, Custom property name
	* @param value String, Custom property value
	* @access public
	* @return void
	*/
	function addProperty($name, $value) {

		##### FIX THESE SETTERS #####
		switch($name) {
			
			case 'city':
				$this->setCity($value);
				break;
			case 'state':
				$this->setState($value);
				break;
			case 'street':
				$this->setStreet($value);
				break;
			case 'type':
				$this->setType($value);
				break;
			case 'zipCode':
				$this->setZipCode($value);
				break;
		}

	}

}
?>
