<?php
include 'setupenv.php';

import('horizon.xml.digester.Digester');

/**
 * A container for all tag libraries that have been imported.
 */
class TagLibraries
{
	var $taglibInfos = array();

	function addTagLibrary($prefix, &$tli)
	{
		$this->taglibInfos[$prefix] =& $tli;
	}

	/**
	 * Determine if the tag provided exists, looking up by
	 * prefix and by shortName against the known tag libraries.
	 *
	 * @param string $prefix The namespace used on the tag element
	 * @param string $shortName The name of the tag
	 * @return boolean Whether or not the tag exists
	 */
	function isDefinedTag($prefix, $shortName)
	{
		if (isset($this->taglibInfos[$prefix]))
		{
			$tli =& $this->taglibInfos[$prefix];
			if ($tli->getTag($shortName) != null)
			{
				return true;
			}
		}

		// @note maybe throw and exception if not found?
		return false;
	}

	function getTagLibInfo($prefix)
	{
		if (!isset($this->tagLibInfos[$prefix]))
		{
			return null;
		}
		
		return $this->tagLibInfoss[$prefix];
	}

	function getTldLocations()
	{
		return array('c.tld');
	}

	function processTlds()
	{
		$tlds = $this->getTldLocations();

		$digester =& $this->initTldDigester();

		// try {
		foreach ($tlds as $tld)
		{
			$tli =& $digester->parse(new FileReader($tld));
			$this->addTagLibrary($tli->getPrefix(), $tli);
		}
		// } catch (RootException $ex) {
		if ($ex = catch_exception())
		{
			// @fixme make me do something useful rather than stop
			$ex->printStackTrace();
			exit;
		}
	}

	function &initTldDigester()
	{
		$digester =& new Digester();

		$digester->addObjectCreate('taglib', 'horizon.xml.digester.tests.TagLibraryInfo');

		$digester->addBeanPropertySetter('taglib/tlib-version', 'version');

		$digester->addBeanPropertySetter('taglib/short-name', 'prefix');

		$digester->addBeanPropertySetter('taglib/uri');

		$digester->addObjectCreate('taglib/tag', 'horizon.xml.digester.tests.TagInfo');

		$digester->addBeanPropertySetter('taglib/tag/name');

		$digester->addBeanPropertySetter('taglib/tag/tag-class', 'tagClass');

		$digester->addSetNext('taglib/tag', 'addTag', 'horizon.xml.digester.tests.TagInfo');

		return $digester;	
	}
}

$o =& new TagLibraries();
$o->processTlds();
print_r($o);
?>
