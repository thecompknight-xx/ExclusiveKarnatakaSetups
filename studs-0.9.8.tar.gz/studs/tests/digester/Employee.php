<?php
/* $Id: Employee.php 188 2005-04-07 04:52:31Z mojavelinux $
 *
 * Copyright 2003-2005 Dan Allen, Mojavelinux.com (dan.allen@mojavelinux.com)
 *
 * This project was originally created by Dan Allen, but you are permitted to
 * use it, modify it and/or contribute to it.  It has been largely inspired by
 * a handful of other open source projects and public specifications, most
 * notably Apache's Jakarta Project and Sun Microsystem's J2EE SDK.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



/**
* Bean for Digester testing.
*/
class Employee {

	var $parameters = array();

	var $displayName = null;

	var $addresses = array(); // ArrayList

	function Employee()
	{
	}

	function addAddress($address)
	{
        $this->addresses[] = $address;	// Address object
    }

	function &getAddress($type) {	// String Eg: $employee->getAddress("office")

		foreach($this->addresses as $k => $oAddr) {
			if( $type == $oAddr->getType() )	// ["home"|"office"|..]
				return $oAddr;
			}
			return NULL;
		}

		// !!!!!!!!!
		function removeAddress($address) {
			$this->addresses[$address] = NULL; // Address
		}

		var $firstName = null; // private String

		function getFirstName() {
			return $this->firstName;
		}

		function setFirstName($firstName) {
			$this->firstName = $firstName; // String
		}

		var $lastName = null; // private String

		function getLastName() {
			return $this->lastName;
		}

		function setLastName($lastName) {
			$this->lastName = $lastName; // String
		}

		// this is to allow testing of primitive convertion 
		var $age;		// private int
		var $active;	// private boolean
		var $salary;	// private float
        
		function getAge() {
			return $this->age;
		}
    
		function setAge($age) {
			$this->age = $age;
		}
    
		function isActive() {
			return $this->active;
		}
    
		function setActive($active) {
			$this->active = $active;
		}
    
		function getSalary() {
			return $this->salary;
		}
    
		function setSalary($salary) {
			$this->salary = $salary;
		}

	function addParameter($name, $value)
	{
		$this->parameters[$name] = $value;
	}

	function &getParameters()
	{
		return $this->parameters;
	}

	function setDisplayName($name)
	{
		$this->displayName = $name;
	}

	function getDisplayName()
	{
		return $this->displayName;
	}

	function toString() {
		$sb = 'Employee[';
		$sb .= 'firstName=';
		$sb .= $this->firstName;
		$sb .= ', lastName=';
		$sb .= $this->lastName;
		$sb .= ', age=';
		$sb .= $this->age;
		$sb .= ', active=';
		$sb .= $this->active;
		$sb .= ', salary=';
		$sb .= $this->salary;
		$sb .= ']';
		return $sb;
	}
}
?>
