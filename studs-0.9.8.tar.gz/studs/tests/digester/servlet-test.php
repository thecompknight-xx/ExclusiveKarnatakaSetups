<?php
/**
 * necessary initialization which would normally be in .htaccess
 */
error_reporting(E_ALL);
ini_set('include_path', './:../../../../');

/**
 * bootstrap our horizon class library framework
 */
require_once 'horizon/init.php';

import('horizon.util.StopWatch');
import('horizon.io.FileReader');
import('horizon.xml.digester.Digester');
import('stratus.http.HttpServletRequest');
import('stratus.http.HttpServletResponse');
import('stratus.core.StandardContext');
import('stratus.config.WebRuleSet');

$reader =& new FileReader($tmp = 'web.xml');
$stopWatch = new StopWatch();
// 1.
$string = '';
while ($reader->read($string, strlen($string)) > 0)
{
}
// 2.
//$string = file_get_contents('web.xml');
echo $string . ' in ' . $stopWatch->read(); exit;

import('horizon.io.StringReader');
$reader =& new StringReader(implode('', $buffer));
$buffer = array_fill(0, 10, null);
while ($reader->read($buffer) > 0)
{
}
echo implode('', $buffer);
exit;

/**
if (file_exists('HttpServletRequest.data'))
{
	import('horizon.io.FileReader');
	$request =& Clazz::readObject(new FileReader($tmp = 'HttpServletRequest.data'), new FileReader($tmp = 'HttpServletRequest.paths'));
	echo $request->getAttribute('foo');
}
else
{
	import('stratus.http.HttpServletRequest');
	$request =& new HttpServletRequest();
	$request->setAttribute('foo', $tmp = 'bar');
	import('horizon.io.FileWriter');
	$request->writeObject(new FileWriter($tmp = 'HttpServletRequest.data'), new FileWriter($tmp = 'HttpServletRequest.paths'));
}
exit;
/**/

/**
 * We are the <code>HttpProcessor</code>.  Since Apache already does all the work
 * of listening on a socket and dispatching the request, we just pick up from here
 * and call the invoke() method on the <code>Container</code> using an <code>HttpServletRequest</code>
 * and <code>HttpServletResponse</code> here (which again are all filled with lots of juicy info
 * because PHP did all that work for us.  Basically we aren't starting from scratch, so
 * we just bootstrap it here with what we have and continue down the chain of responsibility.
 */

$context =& new StandardContext(); 
$digester =& new Digester();
$digester->setNamespaceAware(true);
$digester->setValidating(true);
$digester->addRuleSet(new WebRuleSet());
$digester->push($context);
$digester->parse(new FileReader($tmp = 'WEB-INF/web.xml'));

$request =& new HttpServletRequest();
$response =& new HttpServletResponse();
$context->invoke($request, $response);
?>
