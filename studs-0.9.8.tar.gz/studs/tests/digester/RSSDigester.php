<?php
/* $Id: RSSDigester.php 223 2005-06-23 23:11:06Z mojavelinux $
 *
 * Copyright 2003-2005 Dan Allen, Mojavelinux.com (dan.allen@mojavelinux.com)
 *
 * This project was originally created by Dan Allen, but you are permitted to
 * use it, modify it and/or contribute to it.  It has been largely inspired by
 * a handful of other open source projects and public specifications, most
 * notably Apache's Jakarta Project and Sun Microsystem's J2EE SDK.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

include 'setupenv.php';

import('horizon.io.FileReader');
import('horizon.xml.digester.Digester');

class RSSDigester extends Digester
{
	function configure()
	{
        if ($this->configured)
		{
            return;
        }

        // Add the rules for the Channel object
        $this->addObjectCreate('rss/channel', 'horizon.xml.digester.tests.Channel');
        $this->addBeanPropertySetter('rss/channel/copyright');
        $this->addBeanPropertySetter('rss/channel/description');
        $this->addBeanPropertySetter('rss/channel/language');
        $this->addBeanPropertySetter('rss/channel/lastBuildDate');
        $this->addBeanPropertySetter('rss/channel/link');
        $this->addBeanPropertySetter('rss/channel/managingEditor');
        $this->addBeanPropertySetter('rss/channel/title');
        $this->addBeanPropertySetter('rss/channel/webMaster');

        // Add the rules for the Item object
        $this->addObjectCreate('rss/channel/item', 'horizon.xml.digester.tests.Item');
        $this->addSetNext('rss/channel/item', 'addItem', 'horizon.xml.digester.tests.Item');
        $this->addBeanPropertySetter('rss/channel/item/description');
        $this->addBeanPropertySetter('rss/channel/item/link');
        $this->addBeanPropertySetter('rss/channel/item/title');

        // Mark this digester as having been configured
        $this->configured = true;
	}

	function &digest($fileNameOrUrl)
	{
		$rssDigester =& new RSSDigester();
		// try{
		$channel =& $rssDigester->parse(new FileReader($fileNameOrUrl));
		// } catch (RootException $e) {
		if ($e = catch_exception())
		{
			$e->printStackTrace();
			exit;
		}

		return $channel;
	}
}

$url = 'http://raibledesigns.com/rss/rd';
$channel =& RSSDigester::digest($url);
echo 'Lasted news from ' . $channel->getTitle() . "\n";
$items = $channel->getItems();
foreach ($items as $index => $item)
{
	echo ($index + 1) . '. ' . $item->getTitle() . "\n";	
}
?>
