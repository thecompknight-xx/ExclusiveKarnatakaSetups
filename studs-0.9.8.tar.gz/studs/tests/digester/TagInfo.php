<?php
class TagInfo
{
	var $name;

	var $tagClass;

	function TagLibraryInfo($name = null, $tagClass = null)
	{
		$this->name = $name;
		$this->tagClass = $tagClass;
	}

	function setName($name)
	{
		$this->name = $name;
	}

	function getName()
	{
		return $this->name;
	}

	function setTagClass($tagClass)
	{
		$this->tagClass = $tagClass;
	}

	function getTagClass()
	{
		return $this->tagClass;
	}
}
?>
