<?php
include_once 'setupenv.php';

import('horizon.io.File');

$file =& new File('.');
$files =& $file->listFileNames();
foreach ($files as $file)
{
	echo $file . "\n";
}
?>
