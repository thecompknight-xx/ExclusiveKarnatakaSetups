<?php
import('horizon.util.unittest.TestCase');
import('phase.compiler.PhaseCompiler');
import('phase.compiler.MockPhaseObjects');

class PhaseCompilerTest extends TestCase
{
	var $ctxt;

	var $wrapper;

	var $phaseTestFile;

	function setup()
	{
		$this->ctxt =& new MockPhaseCompilationContext();
		@unlink($this->ctxt->getCompiledFileName());
	}

	/**
	 * Test the compilation of a phase file, test.in, which includes
	 * both scriptlets and basic tag libraries.  The resource should
	 * be a compiled test.out file in the same directory.
	 */
	function testCompile()
	{
		$compiler =& new PhaseCompiler($this->ctxt, $this->wrapper);
		$compiler->compile();
		$result =& new File($this->ctxt->getCompiledFileName());	
		$this->assertTrue($result->exists(), 'Compiled file was not generated');
		// TODO: more checking on validity!
	}

	function testCompileELEnabled()
	{
		$options =& $this->ctxt->options;
		$options->setElIgnored(false);

		$compiler =& new PhaseCompiler($this->ctxt, $this->wrapper);
		$compiler->compile();
		$result =& new File($this->ctxt->getCompiledFileName());	
		$this->assertTrue($result->exists(), 'Compiled file was not generated');
		// TODO: more checking on validity!
	}
}
?>
