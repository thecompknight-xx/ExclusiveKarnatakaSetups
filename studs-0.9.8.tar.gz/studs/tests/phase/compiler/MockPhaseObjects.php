<?php
import('horizon.io.FileReader');
import('stratus.core.ApplicationContext');

class MockPhaseCompilationContext extends Object
{
	var $options;

	function MockPhaseCompilationContext()
	{
		$this->options =& new MockPhaseServletOptions();
	}

	function getResourcePaths($path)
	{
		return @ApplicationContext::getResourcePaths($path);
	}

	function &getResourceAsStream($path)
	{
		return new FileReader($path);
	}

	function getCompiledFileName()
	{
		return dirname(__FILE__) . '/test.out';
	}

	function getPhaseFile()
	{
		return dirname(__FILE__) . '/test.in';
	}
}

class MockPhaseServletOptions extends Object
{
	var $elIgnored = true;

	function isElIgnored()
	{
		return $this->elIgnored;
	}

	function setElIgnored($status)
	{
		$this->elIgnored = $status;
	}

	function getTldResourceDir()
	{
		return dirname(__FILE__);
	}
}
?>
