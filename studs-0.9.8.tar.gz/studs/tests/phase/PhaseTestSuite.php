<?php
import('horizon.util.unittest.TestSuite');
import('horizon.util.unittest.TestResult');

class PhaseTestSuite extends TestSuite
{
	/**
	 * Create the test suite instance, adding the various tests to
	 * be run, then return the suite.
	 *
	 * @static
	 */
	function &suite()
	{
		$suite =& new TestSuite();
		$suite->addTestSuite(Clazz::forName('phase.compiler.PhaseCompilerTest'));
		return $suite;
	}
}
?>
