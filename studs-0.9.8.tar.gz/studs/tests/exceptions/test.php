<?php
include_once 'setupenv.php';

// try {
foo();
// } catch (RootException $e) {
if ($e = catch_exception())
{
}
// }

function foo()
{
	$foo = 0;
	do
	{
	throw_exception(new RootException("fools"));
	$e = catch_exception();
	$e->printStackTrace();
	$foo++;
	} while ($foo < 2);
}
?>
