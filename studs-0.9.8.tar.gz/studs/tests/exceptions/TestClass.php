<?php
class TestClass
{
	var $bar = 'foo';

	function Test()
	{
	}

	function hey()
	{
		throw_exception(new RootException("fool"));
	}

	function bar()
	{
		$this->hey();
	}
}
?>
