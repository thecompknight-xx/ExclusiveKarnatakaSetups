<?php
# call using: php -q -d allow_call_time_pass_reference=1 testrunner.php ExampleTestSuite
header('Content-type: text/plain');

error_reporting(E_ALL);
ini_set('include_path', implode(':', array('.', '../src', '../tests')));

require_once 'horizon/init.php';

import('horizon.util.unittest.runner.TextRunner');
TextRunner::main($_SERVER['argv']);
?>
